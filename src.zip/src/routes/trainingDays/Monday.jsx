import WorkoutTypeCard from "../../components/WorkoutTypeCard";

export default function Monday() {
  return (
    <>
      <WorkoutTypeCard workoutDay={"Monday"} />
    </>
  );
}
